using System;

namespace $safeprojectname$;

public class $safeprojectname$
{
    public bool Foo(int val)
    {
        throw new NotImplementedException("Not implemented.");
    }
}