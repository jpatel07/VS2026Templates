using System;
using Xunit;
using $ext_safeprojectname$;

namespace $safeprojectname$;

public class $ext_safeprojectname$Tests
{
    [Fact]
    public void Foo_InputIs1_ReturnFalse()
    {
        var sut = new $ext_safeprojectname$();
        Assert.Throws<NotImplementedException>(() => sut.Foo(0));
    }
}